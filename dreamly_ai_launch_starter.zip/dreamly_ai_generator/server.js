import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "2mb" }));
app.use(express.static(__dirname));

const allowedSizes = new Set(["1024x1024", "1536x1024", "1024x1536"]);
const allowedQualities = new Set(["low", "medium", "high"]);

app.post("/api/generate", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "Server is missing OPENAI_API_KEY. Add it to .env and restart." });
    }
    const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
    const size = allowedSizes.has(req.body?.size) ? req.body.size : "1024x1024";
    const quality = allowedQualities.has(req.body?.quality) ? req.body.quality : "medium";
    const n = Math.max(1, Math.min(4, Number.parseInt(req.body?.n, 10) || 1));
    if (!prompt) return res.status(400).json({ error: "Please provide an image prompt." });
    if (prompt.length > 1500) return res.status(400).json({ error: "Prompt is too long (maximum 1,500 characters)." });

    // Do not trust frontend controls for security or quotas. Add authentication,
    // moderation, rate limits, and per-user credit enforcement before public launch.
    const result = await openai.images.generate({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1",
      prompt,
      size,
      quality,
      n
    });
    const images = (result.data || [])
      .filter(item => item.b64_json)
      .map(item => `data:image/png;base64,${item.b64_json}`);
    if (!images.length) return res.status(502).json({ error: "The image API returned no base64 images." });
    return res.json({ images });
  } catch (err) {
    console.error("Image generation error:", err?.status || "", err?.message || "Unknown error");
    const status = err?.status === 401 ? 502 : 500;
    return res.status(status).json({
      error: err?.status === 401
        ? "The server API key was rejected. Check OPENAI_API_KEY."
        : "Image generation failed. Check your API access, model settings, and server logs."
    });
  }
});

app.listen(port, () => console.log(`Dreamly is running at http://localhost:${port}`));
