# Dreamly — AI Image Generator

A responsive frontend for a prompt-based AI image generator, with a Node.js/Express backend example. The frontend is usable as a design demo, but **real generation requires an API key and a running backend**.

## Features
- Prompt entry, style, aspect ratio, quality, and number of images
- Result preview, download, copy prompt, and regenerate
- Responsive layout and prompt inspiration gallery
- Backend endpoint keeps the API key off the browser
- Clear status and error messages

## Requirements
- Node.js 20+
- An OpenAI API key with access to image generation
- API usage billing/limits configured for your account

## Run locally
1. Install Node.js.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and add your API key.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Never put your API key into `index.html`, client-side JavaScript, or a public repository.

## Deploy
Deploy the project to a Node-capable host. Configure `OPENAI_API_KEY` as a server-side environment secret. Set spending limits and rate limits before public launch. If deploying frontend and backend separately, change `API_ENDPOINT` in `index.html` to your backend URL and configure CORS narrowly for your domain.

## Important production tasks
This starter is not a complete commercial service yet. Before opening it to the public:
- Add authentication and a database if users need accounts/history.
- Enforce free credits and paid entitlements on the server; client-only credit counters are not secure.
- Add request throttling, per-user quotas, prompt/output moderation, logging without unnecessarily retaining private prompts, and cost monitoring.
- Add a privacy policy, terms, and content rules.
- Implement payments with a trusted billing provider; never store card details yourself.
- Confirm model, image-size, quality, and output format availability against current API documentation.
- Use a persistent image store if users need permanent links; this starter returns image data directly.

## API endpoint
`POST /api/generate`
```json
{
  "prompt": "A cozy cabin in the snow, warm cinematic lighting",
  "size": "1024x1024",
  "quality": "medium",
  "n": 1
}
```
Response:
```json
{ "images": ["data:image/png;base64,..."] }
```
The included server uses the OpenAI Node SDK and `gpt-image-1`. API access and model names can change; check the current OpenAI image-generation documentation if you receive an access/model error.

## Logo
The custom Dreamly AI logo is included as `logo.svg` and is loaded by the site header. You can use it on your site and adapt the SVG colors or sizing as needed.


## Render deployment starter
A `render.yaml` Blueprint is included for the initial public web service. Push this folder to a GitHub repository, then in Render choose **New → Blueprint** and connect that repository. During setup, supply `OPENAI_API_KEY` as a secret in Render, not in source control. Render will provide an `onrender.com` URL when the deployment succeeds.

### Important trial / paid membership status
The current starter does **not yet implement user accounts, database-backed trial dates, free-credit enforcement, or payment checkout**. The 7-day no-card trial should be implemented only after adding real authentication and a persistent database:
- On signup, save `plan = 'trial'`, `trial_started_at = now()`, and `trial_ends_at = now() + 7 days`.
- For each generation request, check the authenticated user in the backend; if now >= trial_ends_at, switch to `free` and apply free-tier limits.
- Never rely on a browser-only timer or localStorage to enforce access.
- Store trial status and generation counts in PostgreSQL; enforce rate limits and server-side quotas.
- Premium price target: PHP 199/month. Do not activate billing until a payment provider is configured and the checkout/renewal/cancellation flow is tested.
